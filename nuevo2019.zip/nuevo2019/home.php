<?php
session_start();
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==null){
	print "<script>alert(\"Acceso invalido!\");window.location='login.php';</script>";
}

?>
<html>
	<head>
		<title>.: HOME :.</title>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
		  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css'>
			<link rel="stylesheet" href="./style.css">
     	<link rel="stylesheet" href="./style2.css">
     	<link rel="stylesheet" href="./style3.css">
	</head>
	<body>
	<?php include "php/navbar.php"; ?>
<div class="container">
		<h2>Bienvenido</h2>

<table bordercolor="#0000FF"  width="1080" height="21" border="2" cellpadding="0" cellspacing="0" align="center">
    <tr>
      <th  width="1076" scope="col"><marquee scrolldelay="80">
        ¡¡¡ Bienvenido !!!    Gracias por entrar a nuestra pagina web, tenemos a la venta diferentes productos.
      </marquee></th>
    </tr>
  </table><br>

<!-- MENU HORIZONTAL BOTONES -->
<table width="center" align="center" cellpadding="0" cellspacing="0">
       <tr>
       	<button style="margin-right:10px" type="button" class="btn btn-success" href=""> INICIO</button>
       	<button style="margin-right:10px" type="button" class="btn btn-success" href="">NOSOTROS</button>
       	<button style="margin-right:10px" type="button" class="btn btn-success" href="">SERVICIOS</button>
       	<button style="margin-right:10px" type="button" class="btn btn-success" href="">PRODUCTOS</button>
       	<button style="margin-right:10px" type="button" class="btn btn-success" href="">CONTACTO</button>
       </tr>
</table><br>

<!-- CARRUCEL CON IMAGENES -->
<div class="container--head">
  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <div class="carousel-tooltip">
      <div class="caraousel-tooltip-item active" data-index="0"></div>
      <div class="caraousel-tooltip-item" data-index="1"></div>
      <div class="caraousel-tooltip-item" data-index="2"></div>
      <div class="caraousel-tooltip-item" data-index="3"></div>
      <div class="caraousel-tooltip-item" data-index="4"></div>
    </div>

    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
      <li data-target="#carousel-example-generic" data-slide-to="1"></li>
      <li data-target="#carousel-example-generic" data-slide-to="2"></li>
      <li data-target="#carousel-example-generic" data-slide-to="3"></li>
      <li data-target="#carousel-example-generic" data-slide-to="4"></li>
      <li data-target="#carousel-example-generic" data-slide-to="5"></li>
      <li data-target="#carousel-example-generic" data-slide-to="6"></li>      
      <li data-target="#carousel-example-generic" data-slide-to="7"></li>
    </ol>

<div class="carousel-inner">
      <div class="item active">
        <img src="https://www.mipatente.com/wp-content/uploads/2016/10/plagio-head-9141-1.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
        </div>
      </div>
       <div class="item">
        <img src="https://jesusgarciafernandez.com/wp-content/uploads/2018/12/optimizacion-seo.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
        </div>
      </div>
      <div class="item">
        <img src="https://webhosting-latino.com/wp-content/uploads/2018/09/networking-1.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
        </div>
      </div>
      <div class="item">
        <img src="https://k61.kn3.net/taringa/7/B/A/A/9/D/Miyata1987/F61.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
        </div>
      </div>
      <div class="item">
        <img src="https://restore.com.bo/wp-content/uploads/2018/03/banner_restore_1.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
        </div>
      </div>
      <div class="item">
        <img src="https://www.infordio.com/images/cableado-estructurado-aleben-telecom_0.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
        </div>
      </div>
      <div class="item">
        <img src="https://media.licdn.com/media-proxy/ext?w=800&h=800&hash=0%2F%2BF1HLSIduI6CLKDLOMv9mZie8%3D&ora=1%2CaFBCTXdkRmpGL2lvQUFBPQ%2CxAVta5g-0R6nlh8Tw1It6a2FowGz60oIQY_PTWn8CnL_5aaEFXbrCKapO-z41jJBcVNm_3UtLq3sGWO9R47vdMy6P7Mo1saycY2nbhUPZxcJ0zkf04NraUlr5cujWLmhNXcegLgMPX_7JeTrYkY-TDFq976DC5bPGGsA6QCjQtfgC-pvaqJN9tV7zFRRopyRAJlq7NRS6mN8xW-J6w" alt="..." style="width:100%">
        <div class="carousel-caption">
        </div>
      </div>
      <div class="item">
        <img src="http://www.cienciamx.com/images/1-HEAD_inteliart0819.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
        </div>
      </div>
</div>

   <!-- Controls -->
    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
    </a>
  </div>
</div>

<br><br><br><br>

   <!-- GRID CON IMAGENES -->
<div class="Container">
			<ul class="Gallery"><!--
				--><li class="Gallery-item">
            <figure>
              <img src="http://placekitten.com/g/300/200" alt="image1" />
              <figcaption><p>Image 1</p></figcaption>
            </figure>
				</li><!--
				--><li class="Gallery-item">
					<figure>
						<img src="http://placebacon.net/300/200" alt="image2" />
						<figcaption><p>Image 2</p></figcaption>
					</figure>
				</li><!--
				--><li class="Gallery-item">
						<figure>
							<img src="http://lorempixel.com/300/200/" alt="image3" />
							<figcaption><p>Image 3</p></figcaption>
						</figure>
				</li><!--
				--><li class="Gallery-item">
						<figure>
							<img src="http://lorempixel.com/600/400/" alt="image4" />
							<figcaption><p>Image 4</p></figcaption>
						</figure>
				</li><!--
   --></ul>
		</div>

<br><br><br>

   <!-- GRID CON PROYECTOS -->
 <div class="wrapper">
  <img src="https://placeimg.com/320/240/animals" />
  <img src="https://placeimg.com/320/240/nature" />
  <img src="https://placeimg.com/320/240/people" />
  <img src="https://placeimg.com/320/240/tech" />
  <img src="https://placeimg.com/320/240/grayscale" />
  <img src="https://placeimg.com/320/240/sepia" />
  <img src="https://placeimg.com/320/240/architecture" />
  <img src="https://placeimg.com/320/240/animals" />
  <img src="https://placeimg.com/320/240/any" />
</div>


<br><br>
<!-- FOOTER -->
<footer>
<table>
      <tr>
        <td height="32"><p><span class="Estilo8" color="#ffffff"><em>Copyright &copy; 2019 Todos los Derechos Reservados</em> Desarrollador: David Ferney Cruz.    davidferneycruz@gmail.com</span></p></td>
      </tr>
    </table>
    </footer>



</div>

<!-- Bootstrap -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js'></script>
    <script  src="./script.js"></script>

	</body>
</html>